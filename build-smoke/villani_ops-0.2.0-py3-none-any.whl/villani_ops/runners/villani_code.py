from __future__ import annotations
import os, subprocess, shutil, json, signal, time
from pathlib import Path
from .base import RunnerContext, RunnerResult
from .villani_code_debug import write_runner_telemetry
from villani_ops.subprocess_utils import resolve_command_prefix
from villani_ops.providers import villani_code_provider

def provider_for_villani_code_cli(provider: str) -> str:
    return villani_code_provider(provider)

class VillaniCodeRunner:
    name='villani_code'
    def build_prompt(self, c: RunnerContext) -> str:
        return f"""Objective:\n{c.task_instruction}\n\nSuccess criteria:\n{c.success_criteria or 'Not provided'}\n\nAttempt: {c.attempt_id}\nWork only in repo: {c.repo_path}\n"""
    def run(self, context: RunnerContext) -> RunnerResult:
        command_name=context.backend.command_name or 'villani-code'
        command_prefix=resolve_command_prefix(command_name)
        if command_prefix is None:
            return RunnerResult(exit_code=127, stderr=f"Villani Code command '{command_name}' was not found.")
        api_key=context.backend.resolved_api_key() or ''
        prompt=self.build_prompt(context); max_tokens=str(context.backend.max_tokens or 50000)
        cli_provider=provider_for_villani_code_cli(context.backend.provider)
        provider_warning=None
        if (context.backend.provider or "").strip().lower() and cli_provider == context.backend.provider and cli_provider not in {"openai", "anthropic"}:
            provider_warning=f"Unknown Villani Code CLI provider mapping for '{context.backend.provider}'; passing through unchanged."
        debug_dir = Path(context.run_dir) / 'villani_code_debug'
        debug_dir.mkdir(parents=True, exist_ok=True)
        telemetry_path = Path(context.run_dir) / 'runner_telemetry.json'
        prompt_path = Path(context.run_dir) / 'villani_code_prompt.txt'
        prompt_path.write_text(prompt, encoding='utf-8')
        safe_inline_limit = int(os.environ.get('VILLANI_CODE_INLINE_PROMPT_LIMIT', '12000'))
        if len(prompt) > safe_inline_limit:
            cmd=[command_name,'run','--task-file',str(prompt_path),'--base-url',context.backend.base_url or '', '--model',context.backend.model,'--repo',context.repo_path,'--provider',cli_provider,'--api-key',api_key,'--auto-approve','--no-stream','--max-tokens',max_tokens,'--debug','trace','--debug-dir',str(debug_dir)]
        else:
            cmd=[command_name,'run',prompt,'--base-url',context.backend.base_url or '', '--model',context.backend.model,'--repo',context.repo_path,'--provider',cli_provider,'--api-key',api_key,'--auto-approve','--no-stream','--max-tokens',max_tokens,'--debug','trace','--debug-dir',str(debug_dir)]
        red=[('***REDACTED***' if x==api_key else x) for x in cmd]
        Path(context.run_dir,'villani_code_command.json').write_text(json.dumps(red, indent=2))
        def _result(exit_code:int, stdout='', stderr=''):
            tel=write_runner_telemetry(debug_dir, telemetry_path, context.backend)
            warnings=list(tel.token_accounting_warnings)
            telemetry=tel.model_dump(mode='json')
            if provider_warning:
                warnings.append(provider_warning)
                telemetry.setdefault('token_accounting_warnings', []).append(provider_warning)
            return RunnerResult(exit_code=exit_code, stdout=stdout or '', stderr=stderr or '', input_tokens=tel.input_tokens, output_tokens=tel.output_tokens, total_tokens=tel.total_tokens, total_cost=(context.backend.estimate_cost(tel.input_tokens,tel.output_tokens) if tel.token_accounting_status != "missing" else None), debug_artifact_dir=str(debug_dir), resolved_trace_dir=tel.resolved_trace_dir, telemetry_path=str(telemetry_path), duration_ms=tel.duration_ms, model_requests=tel.model_requests, model_failures=tel.model_failures, total_tool_calls=tel.total_tool_calls, tool_calls_by_name=tel.tool_calls_by_name, total_file_reads=tel.total_file_reads, total_file_writes=tel.total_file_writes, commands_executed=tel.commands_executed, commands_failed=tel.commands_failed, first_substantive_file_read_tool_index=tel.first_substantive_file_read_tool_index, first_substantive_file_read_seconds=tel.first_substantive_file_read_seconds, first_file_mutation_tool_index=tel.first_file_mutation_tool_index, first_file_mutation_seconds=tel.first_file_mutation_seconds, first_command_tool_index=tel.first_command_tool_index, first_command_seconds=tel.first_command_seconds, token_accounting_status=tel.token_accounting_status, token_accounting_warnings=warnings, telemetry=telemetry)
        def _norm(x):
            if x is None: return ''
            if isinstance(x, bytes): return x.decode(errors='replace')
            return str(x)
        def _close_pipes(p):
            for stream in (getattr(p,'stdin',None), getattr(p,'stdout',None), getattr(p,'stderr',None)):
                try:
                    if stream: stream.close()
                except Exception: pass
        def _terminate_timed_out_process(p):
            if not p: return
            if os.name == 'posix':
                try: pgid=os.getpgid(p.pid)
                except Exception: pgid=p.pid
                for sig, wait_s in ((signal.SIGTERM, 1.0), (signal.SIGKILL, 2.0)):
                    try: os.killpg(pgid, sig)
                    except ProcessLookupError: pass
                    except Exception:
                        try: os.kill(p.pid, sig)
                        except Exception: pass
                    deadline=time.monotonic()+wait_s
                    while time.monotonic()<deadline and p.poll() is None:
                        time.sleep(0.05)
                    if p.poll() is not None: break
            else:
                try:
                    subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'], text=True, capture_output=True, timeout=5)
                except Exception:
                    try: p.terminate()
                    except Exception: pass
                try: p.wait(timeout=1)
                except Exception:
                    try: p.kill()
                    except Exception: pass
                    try: p.wait(timeout=2)
                    except Exception: pass
            _close_pipes(p)
            try: p.wait(timeout=0.2)
            except Exception: pass
        proc=None
        try:
            popen_kwargs={'cwd':context.repo_path,'text':True,'stdout':subprocess.PIPE,'stderr':subprocess.PIPE,'env':{**os.environ, **context.env}}
            if os.name == 'posix': popen_kwargs['start_new_session']=True
            elif hasattr(subprocess, 'CREATE_NEW_PROCESS_GROUP'): popen_kwargs['creationflags']=subprocess.CREATE_NEW_PROCESS_GROUP
            proc=subprocess.Popen([*command_prefix, *cmd[1:]], **popen_kwargs)
            stdout, stderr = proc.communicate(timeout=context.timeout_seconds)
            return _result(proc.returncode, stdout, stderr)
        except subprocess.TimeoutExpired as e:
            _terminate_timed_out_process(proc)
            r=_result(124, _norm(getattr(e,'stdout',None)), _norm(getattr(e,'stderr',None))+f"\nCommand timed out after {context.timeout_seconds}s")
            r.token_accounting_warnings.append('Runner timed out; telemetry may be partial.')
            r.telemetry.setdefault('token_accounting_warnings', []).append('Runner timed out; telemetry may be partial.')
            Path(telemetry_path).write_text(json.dumps(r.telemetry, indent=2))
            return r

class VillaniCodeAdapter(VillaniCodeRunner):
    name='villani-code'
    def run_task(self, *, repo_path: Path, task: str, success_criteria: str | None, backend_name: str, backend_config, timeout_seconds: int | None, context: dict, artifacts_dir: Path) -> RunnerResult:
        return self.run(RunnerContext(attempt_id=str(context.get('attempt_id') or 'attempt'), repo_path=str(repo_path), task_instruction=task, success_criteria=success_criteria, backend=backend_config, timeout_seconds=timeout_seconds or backend_config.timeout_seconds or 1200, run_dir=str(artifacts_dir)))
