from __future__ import annotations
from typing import Any
from villani_ops.core.acceptance import has_non_empty_patch

STEP = {"classify":"1/8","investigate":"2/8","plan":"3/8","decompose":"4/8","code":"5/8","review":"6/8","select":"7/8","verify":"8/8"}

class ProgressReporter:
    verbose: bool = False
    def start_run(self, *, run_dir: str, mode: str, runner: str, candidate_attempts: int) -> None: pass
    def node_started(self, node: Any) -> None: pass
    def node_completed(self, node: Any, data: Any = None, summary: str | None = None) -> None: pass
    def node_failed(self, node: Any, error: str) -> None: pass
    def node_skipped(self, node: Any, reason: str) -> None: pass
    def candidate_started(self, attempt_id: str, index: int, total: int, backend: str | None = None) -> None: pass
    def candidate_completed(self, attempt_id: str, index: int, total: int, data: dict) -> None: pass
    def review_started(self, attempt_id: str, index: int, total: int) -> None: pass
    def review_completed(self, attempt_id: str, index: int, total: int, data: dict) -> None: pass
    def selector_started(self) -> None: pass
    def selector_completed(self, selection: Any, notes: list[str] | None = None) -> None: pass
    def fallback_used(self, reason: str, selected_attempt_id: str | None) -> None: pass
    def final_decision(self, accepted: bool, winner: str | None = None, reason: str | None = None) -> None: pass
    def step(self, message: str) -> None: pass

class NullProgressReporter(ProgressReporter):
    pass

class ConsoleProgressReporter(ProgressReporter):
    def __init__(self, *, verbose: bool = False): self.verbose = verbose
    def _print(self, msg: str = "") -> None: print(msg, flush=True)
    def start_run(self, *, run_dir: str, mode: str, runner: str, candidate_attempts: int) -> None:
        self._print('Villani Ops run started'); self._print(f'Run directory: {run_dir}'); self._print(f'Mode: {mode}'); self._print(f'Runner: {runner}'); self._print(f'Candidate attempts: {candidate_attempts}'); self._print()
    def node_started(self, node: Any) -> None:
        labels={'classify':'Classifying task','investigate':'Investigating repo','plan':'Planning execution','decompose':'Checking decomposition'}
        if node.kind in labels: self._print(f'[{STEP[node.kind]}] {labels[node.kind]}...')
        if self.verbose and getattr(node,'assigned_backend',None): self._print(f'[{STEP.get(node.kind,"?")}] Backend: {node.assigned_backend}/{getattr(node,"assigned_model","")}')
    def node_completed(self, node: Any, data: Any = None, summary: str | None = None) -> None:
        data=data or {}; k=node.kind
        if k=='classify': self._print(f'[{STEP[k]}] Classification complete: {data.get("category") or data.get("task_type") or "unknown"}, difficulty={data.get("difficulty")}, confidence={data.get("confidence","")}')
        elif k=='investigate':
            if data.get("investigation_fallback_used"): self._print(f'[{STEP[k]}] Investigation fallback used: reason={data.get("investigation_fallback_reason") or ""}')
            else:
                extra=', normalized=true' if data.get("investigation_normalized") else ''
                self._print(f'[{STEP[k]}] Investigation complete: relevant_files={len(data.get("relevant_files") or [])}, confidence={data.get("confidence","")}{extra}')
        elif k=='plan':
            if data.get("planner_fallback_used") or data.get("fallback_used"): self._print(f'[{STEP[k]}] Plan complete using planner fallback: strategy={data.get("strategy")}, candidates={data.get("candidate_attempts") or data.get("candidates")}, reason={data.get("planner_fallback_reason") or ""}')
            else:
                extra=', normalized=true' if data.get("planner_normalized") else ''
                if data.get("planner_repaired"): extra += ', repaired=true'
                self._print(f'[{STEP[k]}] Plan complete: strategy={data.get("strategy")}, candidates={data.get("candidate_attempts") or data.get("candidates")}, decompose={str(bool(data.get("should_decompose"))).lower()}{extra}')
        elif k=='decompose':
            if data.get('decomposition_fallback_to_candidate_path'):
                self._print(f'[{STEP[k]}] Decomposition fallback to candidate path: no executable subtasks produced')
            elif data.get('decomposition_fallback_used') or data.get('fallback_used') or data.get('planner_fallback_used'):
                self._print(f'[{STEP[k]}] Decomposition fallback used: reason={data.get("decomposition_fallback_reason") or data.get("planner_fallback_reason") or data.get("reason") or ""}')
            else:
                extra=', normalized=true' if data.get('decomposition_normalized') or data.get('planner_normalized') else ''
                self._print(f'[{STEP[k]}] Decomposition complete: subtask_count={len(data.get("subtasks") or [])}{extra}')
    def node_skipped(self, node: Any, reason: str) -> None:
        if node.kind=='decompose': self._print(f'[{STEP[node.kind]}] Decomposition skipped: {reason}')
    def node_failed(self, node: Any, error: str) -> None: self._print(f'[{STEP.get(node.kind,"?")}] {node.kind} failed: {error}')
    def candidate_started(self, attempt_id: str, index: int, total: int, backend: str | None = None) -> None: self._print(f'[{STEP["code"]}] Running candidate attempt {index}/{total}' + (f' with {backend}' if backend else '') + '...')
    def candidate_completed(self, attempt_id: str, index: int, total: int, data: dict) -> None: self._print(f'[{STEP["code"]}] Candidate attempt {index} complete: exit={data.get("exit_code")}, changed_files={len(data.get("changed_files") or [])}, patch={"yes" if has_non_empty_patch(data.get("patch_path")) else "no"}')
    def review_started(self, attempt_id: str, index: int, total: int) -> None: self._print(f'[{STEP["review"]}] Reviewing candidate attempt {index}/{total}...')
    def review_completed(self, attempt_id: str, index: int, total: int, data: dict) -> None: self._print(f'[{STEP["review"]}] Review complete: {data.get("decision")}/{data.get("recommended_action")}, score={data.get("score")}, eligible={data.get("acceptance_eligible")}')
    def selector_started(self) -> None: self._print(f'[{STEP["select"]}] Selecting winner...')
    def selector_completed(self, selection: Any, notes: list[str] | None = None) -> None:
        for n in notes or []: self._print(f'[{STEP["select"]}] Selector output used alias/normalization: {n}')
        if getattr(selection,'selector_reason_synthesized',False): self._print(f'[{STEP["select"]}] Selector reason synthesized from candidate evidence')
        if getattr(selection,'selector_fallback_used',False) or getattr(selection,'fallback_used',False):
            self._print(f'[{STEP["select"]}] Selector fallback selected {selection.selected_attempt_id}: {getattr(selection, "selector_fallback_reason", None) or getattr(selection, "fallback_reason", None) or getattr(selection, "summary", "")}')
        elif getattr(selection,'decision',None)=='select': self._print(f'[{STEP["select"]}] Selector chose {selection.selected_attempt_id}')
        else: self._print(f'[{STEP["select"]}] Selector rejected all candidates')
    def fallback_used(self, reason: str, selected_attempt_id: str | None) -> None: self._print(f'[{STEP["select"]}] Selector fallback selected {selected_attempt_id}: {reason}')
    def final_decision(self, accepted: bool, winner: str | None = None, reason: str | None = None) -> None: self._print(f'[{STEP["verify"]}] Final decision: {"accepted" if accepted else "failed"}' + (f', winner={winner}' if winner else f', {reason}' if reason else ''))
